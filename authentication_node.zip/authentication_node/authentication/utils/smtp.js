const nodemailer = require('nodemailer');
const dotenv = require('dotenv');

dotenv.config();

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.SMTP_EMAIL,
    pass: process.env.SMTP_PASSWORD,
  },
});

const sendOtpEmail = async (recipientEmail, otp, _id , role="provider") => {
  const mailOptions = {
    from: process.env.SMTP_EMAIL,
    to: recipientEmail,
    subject: "Your OTP Code",
    text: `Your OTP code is ${otp}. Please do not share this code with anyone. Click on the link below to verify your account.\n\nhttp://localhost:3000/verify/${_id}/${role}`,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("OTP Email sent successfully");
  } catch (error) {
    console.error("Error sending OTP email:", error);
  }
};

module.exports = sendOtpEmail;
