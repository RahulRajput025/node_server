const jwt = require('jsonwebtoken');


const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

const generateToken = (userId, role) => {
  const token = jwt.sign(
    { userId, role },
      "65e98173bdee58ab9fda4b5b8ef7379cc06d490a1f5b4b90c6e7d5bb03a115d5",
    {
      expiresIn: "30d",
    }
  );

  return token;
};

// Middleware to protect routes
const protect = asyncHandler(async (req, res, next) => {
  let token;
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    try {
      token = req.headers.authorization.split(" ")[1];
      const decoded = jwt.verify(
        token,
          "65e98173bdee58ab9fda4b5b8ef7379cc06d490a1f5b4b90c6e7d5bb03a115d5"
      );

      req.user = decoded;
      next();
    } catch (error) {
      res.status(401);
      throw new Error("Not authorized, token failed");
    }
  }

  if (!token) {
    res.status(401);
    throw new Error("Not authorized, no token");
  }
});

const Helpers = { asyncHandler, generateToken, protect };

module.exports = Helpers;
