const bcrypt = require('bcryptjs');
const User = require('../model/userModel');
const Helpers = require('../utils/helpers');
const sendOtpEmail = require('../utils/smtp');

// Register User and Send OTP
const registerUser = Helpers.asyncHandler(async (req, res) => {
  try {
    const { email, name, password, phone } = req.body;

    if (!email || !name || !password || !phone) {
      return res.status(400).json({ message: "All fields are required." });
    }

    const existingUser = await User.findOne({ email: email.toLowerCase() });

    if (existingUser) {
      return res.status(400).json({ message: "Email is already registered." });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const otp = Math.floor(100000 + Math.random() * 900000);

    const newUser = await User.create({
      name,
      email: email.toLowerCase(),
      password: hashedPassword,
      phone,
      otp,
      verified: false,
    });

    await sendOtpEmail(email, otp, newUser._id, "user");

    res.status(201).json({ message: "OTP sent. Please verify.", userId: newUser._id });
  } catch (error) {
    console.error("Error registering user:", error);
    res.status(500).json({ message: "Server error" });
  }
});


// OTP Verification
const verifyOtp = Helpers.asyncHandler(async (req, res) => {
  try {
    const { userId, otp } = req.body;
    
    // // Log the received userId and otp
    // console.log("Received userId:", userId);
    // console.log("Received OTP:", otp);

    // Find the user by userId
    const user = await User.findById(userId);
    
    // Log the user and their otp
    console.log("Found user:", user);
    console.log("Stored OTP:", user ? user.otp : null);

    if (!user) {
      return res.status(400).json({ message: "User does not exist." });
    }

    // Compare stored otp with received otp
    if (user.otp !== otp) {
      return res.status(400).json({ message: "Invalid OTP." });
    }

    user.verified = true;
    user.otp = null;
    await user.save();

    res.status(200).json({ message: "Registration complete. You can now log in.", user: user._id });
  } catch (error) {
    console.error("Error during OTP verification:", error);
    return res.status(500).json({ message: "Server error" });
  }
});


module.exports = { registerUser, verifyOtp };
