const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../model/userModel');
const Helpers = require('../utils/helpers');
const { OAuth2Client } = require('google-auth-library');
const dotenv = require('dotenv');

dotenv.config();

// Login User
const loginUser = Helpers.asyncHandler(async (req, res) => {
  try {
    const { email, password } = req.body;
    // Check if all required fields are provided
    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required." });
    }
    // Find the user by email
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(400).json({ message: "User does not exist." });
    }
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid password." });
    }
    if (!user.verified) {
      return res.status(400).json({ message: "Two-factor authorization is required." });
    }
    const token = jwt.sign({ id: user._id }, "jsonKey", { expiresIn: '1h' });

    const { password: userPassword, ...userDetails } = user._doc; 
    res.status(200).json({ token, user: userDetails });
  } catch (error) {
    console.error("Error during login:", error);
    return res.status(500).json({ message: "Server error" });
  }
});



// LOGON WITH GOOGLE
const loginWithGoogle = Helpers.asyncHandler(async (req, res) =>  {
  try {
    const { idToken } = req.body;

    // Create Google OAuth2 client and verify ID token
    const client = new OAuth2Client(
      // '751807066798-8nqklbu57e90otir3qm0uh8i2nrjkpho.apps.googleusercontent.com',
      // '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'
      process.env.GOOGLE_ID , process.env.GOOGLE_PASSWORD
    );

    const ticket = await client.verifyIdToken({ idToken });
    const payload = ticket.getPayload();
    const { email, name } = payload;
    // Find or create user
    let user = await User.findOne({ email });
    if (!user) {
      user = new User({ name, email, verified: true, googleIdToken: idToken });
      await user.save();
    }
    const token = jwt.sign({ id: user._id }, 'jsonKey', { expiresIn: '30d' });
    res.status(200).json({ token, user });
  } catch (e) {
    console.error('Google login error:', e);
    res.status(500).json({ message: 'Server error' });
  }
});


module.exports = {loginUser , loginWithGoogle};
