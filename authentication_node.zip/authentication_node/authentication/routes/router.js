const express = require('express');
const {registerUser ,verifyOtp } = require('../controller/register');
const {loginUser , loginWithGoogle} = require('../controller/login');

const router = express.Router();

router.post('/register', registerUser);
router.post('/verify-otp', verifyOtp);
router.post('/login', loginUser);  
router.post('/login-with-google', loginWithGoogle);

module.exports = router;
